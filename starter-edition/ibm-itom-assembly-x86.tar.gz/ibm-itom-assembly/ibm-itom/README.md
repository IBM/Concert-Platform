# ITOM Deployment Utilities

Simple deployment script for ITOM (IT Operations Management) components to Kubernetes.

## Overview

**IMPORTANT**: ITOM deploys AFTER Platform and shares all infrastructure:
- Database (uses Platform's PostgreSQL)
- TLS certificates (uses Platform's certs)
- Secrets (uses Platform's secret management)
- Authentication (uses Platform's auth)

This deployment script **ONLY** deploys ITOM component templates from `k8s-templates/`.


### On-Premise Deployment (sw-ent)

```bash
cd platform-central/components/itom/utils/bin

./deploy-k8s.sh --license-acceptance=y \
 --namespace=<same as platform> \
  --scale-config=level_2 \
  --deployment-type=sw-ent \
  --registry=cp.stg.icr.io/cp/platform-hub \
  --tag=v3.0.0-21-20260427.033157-main
```

### SaaS Deployment (mcsp)

```bash
./deploy-k8s.sh --license-acceptance=y \
  --namespace=itom-saas \
  --scale-config=level_2 \
  --deployment-type=mcsp \
  --registry=cp.stg.icr.io/cp/platform-hub \
  --tag=v3.0.0-21-20260427.033157-main
```

### Dry Run (Preview Only)

```bash
./deploy-k8s.sh --license-acceptance=y \
  --namespace=itom-dev \
  --scale-config=level_1 \
  --deployment-type=sw-ent \
  --dry-run
```

## Usage

```bash
./deploy-k8s.sh [OPTIONS]

OPTIONS:
  --namespace NAMESPACE       Kubernetes namespace (required)
  --scale-config LEVEL        Scale configuration: level_0, level_1, level_2, level_3 (required)
  --deployment-type TYPE      Deployment type: sw-ent or mcsp (required)
  --registry REGISTRY         Container registry (default: cp.icr.io/cp)
  --tag TAG                   Image tag (default: latest)
  --dry-run                   Generate YAMLs without applying
  -h, --help                  Show help message
```

## Deployment Types

### Software Enterprise - On-Premise (`--deployment-type=sw-ent`)
- Creates `itom-secrets` with database connection info
- Reads credentials from Platform's `app-cfg-oob-secret`
- Provides database access for ITOM components:
  - `DATAMODELDB_*` (DBNAME, HOST, PASSWORD, PORT, USER)
  - `COORDINATORDB_*` (DBNAME, HOST, PASSWORD, PORT, USER)
  - `CONTEXTFORGEDB_*`, `LLMBINDINGDB_*`, `DASHBOARDDB_*`, `SCHEMAEMBEDDINGSDB_*`
  - `BACKEND_APIKEY` (generated once, preserved on redeployments)

### Managed Cloud Service Platform - SaaS (`--deployment-type=mcsp`)
- No additional secrets created
- Secrets managed by Platform operators
- Components use Platform's shared infrastructure directly

## Scale Configurations

| Level | Description | Use Case |
|-------|-------------|----------|
| `level_0` | Scale down | Scale down |
| `level_1` | minimal | minimal deployments |
| `level_2` | Medium | Development Env (recommended) |
| `level_3` | Large | scale production |

Component teams define resource limits/requests in these files:
- `k8s-templates/level_0.cfg`
- `k8s-templates/level_1.cfg`
- `k8s-templates/level_2.cfg`
- `k8s-templates/level_3.cfg`
